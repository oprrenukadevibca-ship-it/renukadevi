// Example: A simple counter app

// Initialize the counter
let counter = 0;

// Function to increment the counter
function incrementCounter() {
  counter++;
  document.getElementById("counterDisplay").innerText = `Counter: ${counter}`;
}

// Function to reset the counter
function resetCounter() {
  counter = 0;
  document.getElementById("counterDisplay").innerText = `Counter: ${counter}`;
}

// Attach event listeners to buttons
document.getElementById("incrementBtn").addEventListener("click", incrementCounter);
document.getElementById("resetBtn").addEventListener("click", resetCounter);
HTML to test the code:


Copy code
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Counter App</title>
</head>
<body>
  <h1 id="counterDisplay">Counter: 0</h1>
  <button id="incrementBtn">Increment</button>
  <button id="resetBtn">Reset</button>

  <script src="script.js"></script>
</body>
</html>
This code creates a simple counter app where you can increment the counter or reset it to zero. Save the JavaScript code in a file named script.js and link it to the HTML file.

Edit
Perform Analysis

Time complexity

Space complexity
Change Language

Python

C++

Java

C#

JavaScript
Testing Tools

Generate test data

Integrate test cases
More Actions

Perform code review

Explain the code

Add error handling

Make code compilable
